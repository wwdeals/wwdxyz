import disnake
from disnake.ext import commands
from config import token
from disnake import Option, OptionType
from tinydb import TinyDB, Query
from tinydb.operations import increment
import json
from datetime import datetime
db = TinyDB('db.json', indent=4)
VOUCHES_FILE = "vouches.json"

intents = disnake.Intents.all()

def load_vouches():
    try:
        with open(VOUCHES_FILE, "r") as file:
            return json.load(file)
    except FileNotFoundError:
        return []
def save_vouches(vouches):
    with open(VOUCHES_FILE, "w") as file:
        json.dump(vouches, file, indent=4)


class MyBot(commands.Bot):
    def __init__(self, command_prefix, intents):
        super().__init__(command_prefix="!", intents=intents)
    

    async def on_ready(self):

        print(f"Logged in as {self.user} (ID: {self.user.id})")
        print("------------------------------------------------")

bot = MyBot(command_prefix="!", intents=disnake.Intents.all())




@bot.slash_command(
    description="Vouch for another user!",
    options=[
        Option("message", "The vouch message", OptionType.string, required=True),
        Option("stars", "The number of stars for the vouch", OptionType.string, required=True, choices=[
            disnake.OptionChoice(name="⭐", value="⭐"),
            disnake.OptionChoice(name="⭐⭐", value="⭐⭐"),
            disnake.OptionChoice(name="⭐⭐⭐", value="⭐⭐⭐"),
            disnake.OptionChoice(name="⭐⭐⭐⭐", value="⭐⭐⭐⭐"),
            disnake.OptionChoice(name="⭐⭐⭐⭐⭐", value="⭐⭐⭐⭐⭐")
        ]),
        Option("proof", "Proof of the vouch (optional)", OptionType.attachment, required=False)
    ]
)
async def vouch(inter: disnake.ApplicationCommandInteraction, message: str, stars: str, proof: disnake.Attachment = None):
    if inter.channel_id != : # Add channel id here, this deletes the message if it is not in this channel
        await inter.response.send_message("This command can only be used in the vouch channel!", ephemeral=True)
        return
    
    Star = Query()
    if not db.search(Star.type == stars):
        db.insert({'type': stars, 'count': 0})
    db.update(increment('count'), Star.type == stars)

    embed = disnake.Embed(
        title="New Vouch Created!",
        description=" ",
        color=disnake.Color.magenta()
    )
    embed.add_field(name="Stars: ", value=stars, inline=False)
    embed.add_field(name="Comment: ", value=message, inline=False)
    embed.add_field(name="Vouched By: ", value=inter.author.mention, inline=True)
    embed.add_field(name="Vouched at: ", value=f"<t:{int(inter.created_at.timestamp())}:f>", inline=True)
    if proof:
        embed.set_image(url=proof.url)
    embed.set_thumbnail(url=inter.author.display_avatar.url)
    await inter.response.send_message(embed=embed)

    vouch_data = {
        "user_id": str(inter.author.id),
        "user_mention": inter.author.mention,
        "user_avatar":str(inter.author.display_avatar.url),
        "message": message,
        "stars": stars,
        "proof_url": proof.url if proof else None,
        "date": datetime.now().strftime("%d %B %Y %H:%M")
    }
    vouches = load_vouches()
    vouches.append(vouch_data)
    save_vouches(vouches)


@bot.slash_command(
    description="Show vouch statistics"
)
async def stats(inter: disnake.ApplicationCommandInteraction):
    embed = disnake.Embed(
        title="Vouch Statistics",
        color=disnake.Color.magenta()
    )
    stats = db.all()
    for star_rating in stats:
        embed.add_field(name=star_rating['type'], value=str(star_rating['count']), inline=False)
        embed.set_thumbnail(url="")
    await inter.response.send_message(embed=embed)


@bot.slash_command(
    description="Restore Vouches"
)
async def restore(inter: disnake.ApplicationCommandInteraction):
    vouches = load_vouches()
    try:
        for vouch in vouches:
            embed = disnake.Embed(
                title="Restored Vouch",
                description=f" ",
                color=disnake.Color.magenta()
            )
            embed.add_field(name="Stars: ", value=vouch['stars'], inline=False)
            embed.add_field(name="Comment: ", value=vouch['message'], inline=False)
            embed.add_field(name="Vouched By: ", value=vouch['user_mention'], inline=True)
            embed.add_field(name="Vouched at: ", value=vouch['date'], inline=True)
            if vouch['proof_url']:
                embed.set_image(url=vouch['proof_url'])
            embed.set_thumbnail(url=vouch['user_avatar'])
            await inter.send(embed=embed)  
    except Exception as e:
        print(e)
bot.run(token)