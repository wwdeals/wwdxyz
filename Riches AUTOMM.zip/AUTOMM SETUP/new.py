from python_bitcoinlib import AuthServiceProxy, JSONRPCException


rpc_user = "sahil"
rpc_password = "sahil12"
rpc_host = "5.230.171.152"
rpc_port = 9332

rpc_url = f"http://{rpc_user}:{rpc_password}@{rpc_host}:{rpc_port}"
rpc_connection = AuthServiceProxy(rpc_url)

try:

    blockchain_info = rpc_connection.getblockchaininfo()
    print("Blockchain Information:")
    print(blockchain_info)

  
    network_info = rpc_connection.getnetworkinfo()
    print("\nNetwork Information:")
    print(network_info)

    
    wallet_info = rpc_connection.getwalletinfo()
    print("\nWallet Information:")
    print(wallet_info)

except JSONRPCException as e:
    print("An error occurred:", e)
