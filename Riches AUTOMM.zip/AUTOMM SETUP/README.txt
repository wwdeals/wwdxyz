Line 25: Add category ID 
Line 218: Add your TOS
Line 690: Add Role ID
Line 903: Add a transcript channel ID
Line 916: ADD YOUR TOKEN, OR LINK TO A .ENV