import discord
import random
import string
import asyncio
import json
import os
from discord.ext import commands
import base58
import hashlib
from ecdsa import SigningKey, SECP256k1
from ecdsa.util import sigencode_der
import qrcode
import io
import requests
from blockcypher import get_total_balance, simple_spend
import chat_exporter

intents = discord.Intents.all()
intents.guilds = True
intents.guild_messages = True

bot = commands.Bot(command_prefix=".", intents=intents)

# Replace category ID
CATEGORY_ID = # Add category ID
API_TOKEN = "506b172c977c49f4b85383e56b497d19"
file_path = 'ltc.json'

async def get_ltc_to_usd_rate():
    try:
        response = requests.get("https://api.coingecko.com/api/v3/simple/price?ids=litecoin&vs_currencies=usd")
        if response.status_code == 200:
            data = response.json()
            ltc_to_usd = data.get("litecoin", {}).get("usd")
            if ltc_to_usd:
                return ltc_to_usd
    except Exception as e:
        print(f"Error fetching LTC to USD rate: {e}")
    return 75.88

def generate_litecoin_wallet():
  
    private_key = SigningKey.generate(curve=SECP256k1)

   
    public_key = private_key.get_verifying_key()

    
    public_key_bytes = public_key.to_string()
    if public_key_bytes[63] % 2 == 1:
        public_key_compressed = b'\x03' + public_key_bytes[:32]
    else:
        public_key_compressed = b'\x02' + public_key_bytes[:32]

  
    sha256_hash = hashlib.sha256(public_key_compressed).digest()

    
    ripemd160_hash = hashlib.new('ripemd160')
    ripemd160_hash.update(sha256_hash)
    ripemd160_hash = ripemd160_hash.digest()

    
    versioned_ripemd160_hash = b'\x30' + ripemd160_hash

   
    checksum = hashlib.sha256(hashlib.sha256(versioned_ripemd160_hash).digest()).digest()[:4]

   
    address = versioned_ripemd160_hash + checksum

    
    encoded_address = base58.b58encode(address)

   
    address_string = encoded_address.decode('utf-8')

   
    private_key_bytes = b'\xb0' + private_key.to_string()  
    checksum = hashlib.sha256(hashlib.sha256(private_key_bytes).digest()).digest()[:4]
    wif_private_key = base58.b58encode(private_key_bytes + checksum).decode('utf-8')

    return address_string, wif_private_key

def update_private_json(code, address, private_key, deal_amt):
    file_path = 'private.json'
    data = {}

    if os.path.exists(file_path):
        with open(file_path, 'r') as file:
            data = json.load(file)

    data[code] = {
        "address": address,
        "private_key": private_key,
        "deal_amt": deal_amt
    }

    with open(file_path, 'w') as file:
        json.dump(data, file, indent=4)

def generate_code(length=16):
    characters = string.ascii_uppercase + string.digits
    return ''.join(random.choice(characters) for _ in range(length))

def update_ltc_json(code, channel_id, sender_id=None, receiver_id=None, deal_amt=None):
    file_path = 'ltc.json'
    data = {}

    if os.path.exists(file_path):
        with open(file_path, 'r') as file:
            data = json.load(file)

    if code not in data:
        data[code] = {
            "channel_id": channel_id,
            "sender_id": sender_id,
            "receiver_id": receiver_id,
            "deal_amt": deal_amt,
            "transaction_id": None,
            "status": "pending"
        }
    else:
        if sender_id:
            data[code]["sender_id"] = sender_id
        if receiver_id:
            data[code]["receiver_id"] = receiver_id
        if deal_amt:
            data[code]["deal_amt"] = deal_amt

    
    with open(file_path, 'w') as file:
        json.dump(data, file, indent=4)


@bot.event
async def on_ready():
    print(f'We have logged in as {bot.user}')



@bot.event
async def on_guild_channel_create(channel):
    if channel.category and channel.category.id == CATEGORY_ID:
        await asyncio.sleep(2)
        await channel.purge()
        code = generate_code()
        embed = discord.Embed(title="",
                              description=f"DEAL CODE : **{code}**",
                              color=0xFFFFFE)
        await channel.send(embed=embed)

        update_ltc_json(code, channel.id)

        
        embed_request = discord.Embed(description="Please send the **User ID** of the user you are dealing with.",
                                      color=0xFFFFFE)
        await channel.send(embed=embed_request)

        def check(m):
            return m.channel == channel and (m.mentions or any(part.isdigit() for part in m.content.split()))


        async def process_user():
            try:
                
                msg = await bot.wait_for('message', timeout=60.0, check=check)
                mentions = msg.mentions
                user_ids = [part for part in msg.content.split() if part.isdigit()]

                
                valid_users = []
                for user in mentions:
                    if channel.guild.get_member(user.id):
                        valid_users.append(user)

                for user_id in user_ids:
                    member = channel.guild.get_member(int(user_id))
                    if member:
                        valid_users.append(member)

                if not valid_users:
                    
                    invite = await channel.create_invite(max_age=60, max_uses=1, unique=True)
                    embed_invite = discord.Embed(title="Invite",
                                                 description=f"Invite the user to the server: {invite.url}",
                                                 color=0xFFFFFE)
                    await channel.send(embed=embed_invite)
                    return await process_user()  
                else:
                    
                    for user in valid_users:
                        await channel.set_permissions(user, read_messages=True, send_messages=True)
                        embed_mention = discord.Embed(description=f"Added {user.mention} to ticket!.",
                                                      color=0xFFFFFE)
                        await channel.send(f"{user.mention}", embed=embed_mention)
                        await asyncio.sleep(1)
                        guild = channel.guild
                        embed = discord.Embed(
        title=f"Welcome To WWD AUTO MM!",
        description="Your Crypto Will Be Saved Securely Till The End Of This Deal, To Get The Funds Both User Have To Confirmed. We Ensure That Your Deal Gets Completed Successfully. For Any Kind Of Issue Please Contact Support. ",
        color=0xFFFFFE
    )

                        await channel.send(embed=embed)
                     
                        embed2 = discord.Embed(
        title=f"Please Read !",
        description="Please Discuss All Deal Related Things Like, How To Use That, Terms & Condition, Warranty, Etc. This Will Prevent You From Getting Scammed From Anyone. Also Make Sure To Discuss Everythihg In The Ticket Only.. ",
        color=0xff0000
    )
                        await channel.send(embed=embed2)
                        
                        embed3 = discord.Embed(
        title="",
        description= "### Terms of Service (ToS)\n\n**Server Ownership Transfer:**\n- When transferring server ownership, both parties must record the entire process to ensure proper documentation.\n\n**Buying Codes (Nitro, Promo, Redeem, VCC, Tokens, etc.):**\n\n- **For Buyers:**\n  - Begin screen recording before the seller sends any Nitro gift links, codes, VCC, or tokens via direct messages.\n  - Keep recording until you successfully redeem the code or VCC.\n  - For tokens and promotions, if you plan to release them after verification, ensure to record the screen during the checking process.\n\n- **For Sellers:**\n  - Verify that the buyer is prepared to record their screen before sharing any codes.\n  - Do not share any information until you have confirmation from the buyer.\n\n**Exchange Deals:**\n- Ensure you are logged into your account and confirm the receipt of the correct amount before releasing the asset to avoid any losses.\n\n**Member Deals:**\n- If you are purchasing members for your server, take a screenshot showing the current number of members.\n- Set up a welcome message to detect bot activity.\n\n**Important Note:**\n- Not following these procedures can lead to consequences for both parties.\n\n- Discuss the terms of service and any warranties in direct messages or through a support ticket before making any payments. The bot will not prompt you for this, so you must initiate it yourself.\n\n- If you encounter any issues during the transaction, contact the support team immediately.",
        color=0x21e921 
    ) # Add your tos
                        await channel.send(embed=embed3)
                        await asyncio.sleep(1)
                        await send_button_embed(channel, code)
                        print("Send Button Embed Siccessful")
            except asyncio.TimeoutError:
                await channel.send("No user mentioned or ID provided within the time limit.")
        
        await process_user()

async def send_button_embed(channel, code):
    view = RoleSelectionView(code)
    embed = discord.Embed(title="Choose your role", description="Click a button below to select your role in the deal.", color=0xFFFFFE)
    embed.add_field(name="Sender", value="Not selected", inline=True)
    embed.add_field(name="Receiver", value="Not selected", inline=True)
    message = await channel.send(embed=embed, view=view)
    view.message = message
    


class RoleSelectionView(discord.ui.View):
    def __init__(self, code):
        super().__init__(timeout=None)
        self.message = None
        self.sender = None
        self.receiver = None
        self.code = code
        self.temp = 0

    @discord.ui.button(label="Sender", style=discord.ButtonStyle.green, custom_id="sender")
    async def sender_button(self, interaction: discord.Interaction, button: discord.ui.Button):

        if self.sender:
            await interaction.response.send_message("Sender role is already taken!", ephemeral=True)
        elif self.receiver and self.receiver == interaction.user:
            await interaction.response.send_message("You cannot select both roles!", ephemeral=True)
        else:
            self.sender = interaction.user
            embed = self.message.embeds[0]
            embed.set_field_at(0, name="Sender", value=interaction.user.mention, inline=True)
            await self.message.edit(embed=embed)
            await interaction.response.send_message(f"{interaction.user.mention} selected as Sender!", ephemeral=True)
            
            if self.sender and self.receiver:
                if self.temp == 0:
                    await self.disable_buttons()
                    self.temp = 1
                    await send_confirmation_embed(self.message.channel, self.sender, self.receiver, self.code)
                else:
                    print("Already Responded")
                    


    @discord.ui.button(label="Receiver", style=discord.ButtonStyle.green, custom_id="receiver")
    async def receiver_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if self.receiver:
            await interaction.response.send_message("Receiver role is already taken!", ephemeral=True)
        elif self.sender and self.sender == interaction.user:
            await interaction.response.send_message("You cannot select both roles!", ephemeral=True)
        else:
            self.receiver = interaction.user
            embed = self.message.embeds[0]
            embed.set_field_at(1, name="Receiver", value=interaction.user.mention, inline=True)
            await self.message.edit(embed=embed)
            await interaction.response.send_message(f"{interaction.user.mention} selected as Receiver!", ephemeral=True)
            if self.sender and self.receiver:
                if self.temp == 0:
                    await self.disable_buttons()
                    temp = 1
                    await send_confirmation_embed(self.message.channel, self.sender, self.receiver, self.code)
                else:
                    print("Already Responded")

    @discord.ui.button(label="Reset", style=discord.ButtonStyle.red, custom_id="reset")
    async def reset_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.sender = None
        self.receiver = None
        embed = self.message.embeds[0]
        embed.set_field_at(0, name="Sender", value="Not selected", inline=True)
        embed.set_field_at(1, name="Receiver", value="Not selected", inline=True)
        await self.message.edit(embed=embed)
        await interaction.response.send_message("Roles have been reset!", ephemeral=True)

    async def disable_buttons(self):
        for child in self.children:
            child.disabled = True
        await self.message.edit(view=self)

async def send_confirmation_embed(channel, sender, receiver, code):
    view = ConfirmationView(sender, receiver, code)
    embed = discord.Embed(title="Confirm Roles", description="Both users must confirm their roles.", color=0xFFFFFE)
    embed.add_field(name="Sender", value=sender.mention, inline=True)
    embed.add_field(name="Receiver", value=receiver.mention, inline=True)
    message = await channel.send(embed=embed, view=view)
    view.message = message

class ConfirmationView(discord.ui.View):
    def __init__(self, sender, receiver, code):
        super().__init__(timeout=None)
        self.sender = sender
        self.receiver = receiver
        self.sender_confirmed = False
        self.receiver_confirmed = False
        self.message = None
        self.code = code
        self.meow = 0


    @discord.ui.button(label="Confirm", style=discord.ButtonStyle.green, custom_id="confirm")
    async def confirm_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user == self.sender:
            self.sender_confirmed = True
            await interaction.response.send_message(f"{interaction.user.mention} **Has 'Confirmed' The Deal**")
        elif interaction.user == self.receiver:
            self.receiver_confirmed = True
            await interaction.response.send_message(f"{interaction.user.mention} **Has 'Confirmed' The Deal**")
        else:
            await interaction.response.send_message("You are not part of this deal!", ephemeral=True)

        if self.sender_confirmed and self.receiver_confirmed:
            if self.meow == 0:
                self.meow = 1
                update_ltc_json(self.code, self.message.channel.id, self.sender.id, self.receiver.id)
                await interaction.message.channel.send("Both users have confirmed. The deal is now set up. Proceed with the transaction!")
                await process_amount(interaction.message.channel, self.sender, self.receiver, self.code)
                await self.disable_buttons()
            else:
                print("Already Responded")

    @discord.ui.button(label="Retry", style=discord.ButtonStyle.red, custom_id="retry")
    async def retry_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user == self.sender or interaction.user == self.receiver:
            await interaction.response.defer()
            view = RoleSelectionView()
            embed = discord.Embed(title="Choose your role", description="Click a button below to select your role in the deal.", color=0xFFFFFE)
            embed.add_field(name="Sender", value="Not selected", inline=True)
            embed.add_field(name="Receiver", value="Not selected", inline=True)
            message = await interaction.message.channel.send(embed=embed, view=view)
            view.message = message
            await interaction.message.delete()
            self.stop()
        else:
            await interaction.response.send_message("You are not part of this deal!", ephemeral=True)

    async def disable_buttons(self):
        for child in self.children:
            child.disabled = True
        await self.message.edit(view=self)





async def process_amount(channel, sender, receiver, code):
    try:
        await channel.send(f"{receiver.mention}, please provide the deal amount in a single message (int or float):")

        def check(m):
            return m.channel == channel and m.author == receiver

        msg = await bot.wait_for('message', timeout=60.0, check=check)
        deal_amount = msg.content.strip()
        if deal_amount.isdigit() or (deal_amount.replace('.', '', 1).isdigit() and deal_amount.count('.') == 1):
            deal_amount = float(deal_amount) if '.' in deal_amount else int(deal_amount)
            view = DealAmountView(sender, receiver, code, deal_amount)
            embed = discord.Embed(title="Deal Amount Confirmation",
                                  description=f"Is {deal_amount}$ the correct deal amount?",
                                  color=0xFFFFFE)
            message = await channel.send(embed=embed, view=view)
            view.message = message
        else:
            await channel.send("Invalid input. Please provide a valid deal amount.")
            await process_amount(channel, sender, receiver, code)
    except asyncio.TimeoutError:
        await channel.send("No deal amount provided within the time limit.")




class DealAmountView(discord.ui.View):
    def __init__(self, sender, receiver, code, amount=None):
        super().__init__(timeout=None)
        self.sender = sender
        self.receiver = receiver
        self.message = None
        self.code = code
        self.deal_amount = amount
        self.sender_confirmed = False
        self.receiver_confirmed = False
        self.noob = 0

    @discord.ui.button(label="Confirm", style=discord.ButtonStyle.green, custom_id="confirm_amount")
    async def confirm_amount_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user == self.sender:
            self.sender_confirmed = True
            await interaction.response.send_message(f"{interaction.user.mention} confirmed the deal amount.")
        elif interaction.user == self.receiver:
            self.receiver_confirmed = True
            await interaction.response.send_message(f"{interaction.user.mention} confirmed the deal amount.")
        else:
            await interaction.response.send_message("You are not part of this deal!", ephemeral=True)
        
        if self.sender_confirmed and self.receiver_confirmed:
            if self.noob == 0:
                self.noob = 1
                self.confirm_amount_button.disabled = True
                self.retry_amount_button.disabled = True
                await interaction.message.edit(view=self)                
                await send_confirmation_deal_amount(self.message.channel, self.sender, self.receiver, self.code, self.deal_amount)
            else:
                print("Already Responded")


    @discord.ui.button(label="Retry", style=discord.ButtonStyle.red, custom_id="retry_amount")
    async def retry_amount_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.clear_items() 
        await interaction.message.delete() 
        await interaction.channel.send(f"{interaction.user.mention} clicked Retry.")
        await process_amount(interaction.channel, self.sender, self.receiver, self.code)





async def send_confirmation_deal_amount(channel, sender, receiver, code, amount):
    embed = discord.Embed(title="Deal Amount Confirmed",
                          description=f"The deal amount has been set to {amount}$.",
                          color=0xFFFFFE)
    embed.add_field(name="Sender", value=sender.mention, inline=True)
    embed.add_field(name="Receiver", value=receiver.mention, inline=True)
    embed.add_field(name="Code", value=code, inline=True)
    await channel.send(embed=embed)

    
    file_path = 'ltc.json'
    data = {}

    if os.path.exists(file_path):
        with open(file_path, 'r') as file:
            data = json.load(file)

    if code in data:
        data[code]["deal_amt"] = amount

    with open(file_path, 'w') as file:
        json.dump(data, file, indent=4)

    await after_confirmation_deal(channel, sender, receiver, code, amount)


async def after_confirmation_deal(channel, sender, receiver, code, amount):
    ltc_to_usd_rate = await get_ltc_to_usd_rate()
    if ltc_to_usd_rate is not None:
        ltc_amount = amount / ltc_to_usd_rate
        address, private_key = generate_litecoin_wallet()
        update_private_json(code, address, private_key, amount)
        await send_litecoin_info(channel, address, amount, ltc_amount, ltc_to_usd_rate, sender, receiver, code)
    else:
        await channel.send("Failed to fetch LTC to USD rate. Please try again later.")



import discord
import qrcode
import io

class LitecoinInfoView(discord.ui.View):
    def __init__(self, address, amount_ltc):
        super().__init__(timeout=None)
        self.address = address
        self.amount_ltc = amount_ltc
        self.copy_text_button = False
        self.qr_generated = False

    @discord.ui.button(label="Copy Text", style=discord.ButtonStyle.primary, custom_id="copy_text")
    async def copy_text_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self.copy_text_button:
            await interaction.response.send_message(f"{self.address}\n{self.amount_ltc}")
            button.disabled = True
            await interaction.message.edit(view=self)
        else:
            await interaction.response.send_message("The 'Copy Text' button has already been clicked.", ephemeral=True)

    @discord.ui.button(label="Generate QR", style=discord.ButtonStyle.primary, custom_id="generate_qr")
    async def generate_qr_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self.qr_generated:
            qr_data = f"litecoin:{self.address}?amount={self.amount_ltc}"
            qr_img = qrcode.make(qr_data)
            qr_img_bytes = io.BytesIO()
            qr_img.save(qr_img_bytes)
            qr_img_bytes.seek(0)
            
            
            embed = discord.Embed(title="QR Code", description="Here's the QR code for the Litecoin address and amount:", color=0xFFFFFE)
            embed.set_image(url="attachment://qr_code.png")

           
            await interaction.response.send_message(embed=embed, file=discord.File(qr_img_bytes, "qr_code.png"))
            button.disabled = True
            await interaction.message.edit(view=self)
        else:
            await interaction.response.send_message("The QR code has already been generated.", ephemeral=True)

    




async def send_litecoin_info(channel, address, amount_usd, amount_ltc, ltc_to_usd_rate, sender, receiver, code):
  
  
    embed = discord.Embed(title="Payment Invoice",
                          description=f"> {sender.mention} Please send the funds as part of the deal to the Middleman address specified below. To ensure the validation of your payment, please copy and paste the amount provided.",
                          color=0xFFFFFE)
    embed.add_field(name="Litecoin Address", value=address, inline=False)
    embed.add_field(name="Deal Amount (LTC)", value=f"{amount_ltc:.5f} LTC", inline=False)
    embed.add_field(name="Deal Amount (USD)", value=f"${amount_usd}", inline=False)
    embed.set_footer(text=f"LTC to USD Rate: {ltc_to_usd_rate}")

    view = LitecoinInfoView(address, amount_ltc)
    message = await channel.send(embed=embed, view=view)
    await check_transactions(address, message, amount_ltc, code, sender, receiver)



async def get_ltc_to_usd():
    try:
        response = requests.get('https://api.coingecko.com/api/v3/simple/price?ids=litecoin&vs_currencies=usd')
        response_data = response.json()
        return response_data['litecoin']['usd']
    except Exception as e:
        print(f"Error fetching LTC to USD conversion rate: {e}")
        return None


async def check_transactions(address, message, expected_amount_ltc, code, sender, receiver, required_confirmations=1):
   
    api_token = '506b172c977c49f4b85383e56b497d19'
    api_url = f'https://api.blockcypher.com/v1/ltc/main/addrs/{address}?token={api_token}'

    detected_transactions = set()
    remaining_amount = expected_amount_ltc

    while True:
        try:
            print("Trying !!\n\n")
            response = requests.get(api_url)
            response_data = response.json()

            print(f"Response Data: {response_data}") 

           
            if 'unconfirmed_txrefs' in response_data:
                for tx in response_data['unconfirmed_txrefs']:
                    tx_id = tx['tx_hash']
                    confirmations = tx.get('confirmations', 0)
                    usd_ltc2 = await get_ltc_to_usd()
                    value_received = tx['value'] / 1e8  
                    value_received_usd = value_received * usd_ltc2
                    blockchain_url = f"https://live.blockcypher.com/ltc/tx/{tx_id}/"

                   
                    if tx_id not in detected_transactions:
                        embed = discord.Embed(
                            title="Transaction Detected",
                            color=0xFFFFFE
                        )
                        embed.add_field(name="Value Received (LTC)", value=f"{value_received:.8f}")
                        embed.add_field(name="Value Received (USD)", value=f"{value_received_usd:.4f}")
                        embed.add_field(name="Confirmations", value=confirmations)
                        embed.add_field(name="View on Blockchain", value=f"[{tx_id}]({blockchain_url})")
                        embed.set_footer(text=f"Waiting for {required_confirmations} confirmations...")
                        file_path = 'ltc.json'
                        data = {}

                        if os.path.exists(file_path):
                            with open(file_path, 'r') as file:
                                data = json.load(file)

                            
                            with open(file_path, 'w') as file:
                                 json.dump(data, file, indent=4)
                        
                        await message.channel.send(embed=embed)
                        detected_transactions.add(tx_id)

            if 'txrefs' in response_data:
                for tx in response_data['txrefs']:
                    tx_id = tx['tx_hash']
                    confirmations = tx['confirmations']
                    value_received = tx['value'] / 1e8  
                    blockchain_url = f"https://live.blockcypher.com/ltc/tx/{tx_id}/"

                    print(f"Transaction {tx_id} has {confirmations} confirmations and value {value_received:.8f} LTC")  

                    
                    if confirmations >= required_confirmations:
                        print(f"Confirmed Transaction Found: {tx}")  
                        if value_received >= 0.95 * expected_amount_ltc:
                            
                            ltc_to_usd_rate = await get_ltc_to_usd()
                            if ltc_to_usd_rate:
                                amount_received_usd = value_received * ltc_to_usd_rate
                                embed = discord.Embed(title="Payment Received", description="Payment successfully received you can proceed with your deal. Your crypto is safe with us.",color=0x00ff00)
                                embed.add_field(name="Amount (LTC)", value=f"{value_received:.8f}")
                                embed.add_field(name="Amount (USD)", value=f"${amount_received_usd:.2f}")
                               
                            
                                view = DealActionView(sender, receiver, code, amount=value_received_usd)
                                await message.channel.send(embed=embed, view=view)
                                if os.path.exists(file_path):
                                    with open(file_path, 'r') as file:
                                        data = json.load(file)

                                    if code in data:
                                        data[code]["status"] = "Transaction Completed"

                                    with open(file_path, 'w') as file:
                                        json.dump(data, file, indent=4)
                                return
                            else:
                                
                                embed = discord.Embed(title="Payment Received", description=(f"Received {value_received:.8f} LTC\nTransaction ID: {tx_id}\n[View on Blockchain]({blockchain_url})"),color=0x00ff00 )
                                view = DealActionView(sender, receiver, code, amount=value_received_usd)
                                await message.channel.send(embed=embed, view=view)
                            return  
                        else:
                            
                            remaining_amount -= value_received
                            embed = discord.Embed(
                                title="Partial Payment Received",
                                description=(
                                    f"Received {value_received:.8f} LTC. Please pay the remaining {remaining_amount:.8f} LTC to the address {address}. And Ping Admins\n"
                                    f"Transaction ID: {tx_id}\n"
                                    f"[View on Blockchain]({blockchain_url})"
                                ),
                                color=0xffd700
                            )
                            await message.channel.send(embed=embed)
                            detected_transactions.add(tx_id)
                            return

        except Exception as e:
            print(f"Error checking transactions: {e}")

        await asyncio.sleep(30) 



class DealActionView(discord.ui.View):
    def __init__(self, sender, receiver, code, amount=None):
        super().__init__(timeout=None)
        self.sender = sender
        self.receiver = receiver
        self.code = code
        self.deal_amount = amount
        self.sender_confirmed = False
        self.receiver_confirmed = False

    @discord.ui.button(label="Release Deal", style=discord.ButtonStyle.green, custom_id="release_deal")
    async def release_deal_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user == self.sender:
            self.sender_confirmed = True
            view=ConfirmActionView(self.sender, self.receiver, self.deal_amount, self.code)
            await interaction.response.send_message(view=view, ephemeral=True)
        else:
            await interaction.response.send_message("You are not the sender of this deal!", ephemeral=True)

    @discord.ui.button(label="Request Refund", style=discord.ButtonStyle.primary, custom_id="request_refund")
    async def request_refund(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user == self.sender:
            embed = discord.Embed(title="Refund Requested", description=f"{interaction.user.mention} has requested a refund! Please review the deal!", color=0xb28fe8)         
            await interaction.response.send_message("<@>", embed=embed)    # Add a role id here
            button.disabled = True
        else: 
            await interaction.send_message("You are not the sender, you cannot request a refund!")      

with open('private.json') as f:
    private_data = json.load(f)

import blockcypher
import hashlib
import hmac
import base64

class ConfirmActionView(discord.ui.View):
    def __init__(self, sender, receiver, amount_usd, code):
        super().__init__(timeout=None)
        self.sender = sender
        self.receiver = receiver
        self.amount_usd = float(amount_usd)
        self.code = code

    @discord.ui.button(label="Confirm", style=discord.ButtonStyle.green, custom_id="confirm_action")
    async def confirm_action_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user == self.sender:
            await interaction.response.send_message(f"{interaction.user.mention} confirmed to release the funds.", ephemeral=True)
            
            await self.send_receiver_address_request(interaction)
        else:
            await interaction.response.send_message("You are not authorized to confirm this action.", ephemeral=True)

    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.red, custom_id="cancel_action")
    async def cancel_action_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user == self.sender:
            await interaction.response.send_message(f"{interaction.user.mention} clicked Cancel.", ephemeral=True)
        else:
            await interaction.response.send_message("You are not authorized to cancel this action.", ephemeral=True)

    async def send_receiver_address_request(self, interaction: discord.Interaction):
        embed = discord.Embed(
            title="Payment Release Confirmation",
            description=f"{self.receiver.mention}, please provide your LTC address for the payment.",
            color=0xffa500
        )
        await interaction.channel.send(embed=embed)
        await self.wait_for_receiver_address(interaction)

    async def wait_for_receiver_address(self, interaction: discord.Interaction):
        def check(m):
            return m.author == self.receiver and m.channel == interaction.channel

        try:
            msg = await interaction.client.wait_for('message', timeout=6000.0, check=check)
            ltc_address = msg.content
            await interaction.channel.send(f"LTC address received: {ltc_address}")
            await self.complete_payment(interaction, ltc_address, self.code)
        except asyncio.TimeoutError:
            await interaction.channel.send(f"{self.receiver.mention} did not provide an LTC address in time.")

    def sign_transaction(unsigned_tx, private_key):
        key_bytes = bytes.fromhex(private_key)
        message = unsigned_tx['tosign'][0].encode()
        signature = hmac.new(key_bytes, message, hashlib.sha256).digest()
        signature_hex = base64.b64encode(signature).decode()
        signed_tx = {
            'tx': unsigned_tx['tx'],
            'signatures': [signature_hex],
        }
        return signed_tx
    
    
    async def complete_payment(self, interaction: discord.Interaction, ltc_address: str, code: str):
        try:
        
            response = requests.get('https://min-api.cryptocompare.com/data/price?fsym=LTC&tsyms=USD')
            response.raise_for_status()
            ltc_price_usd = response.json().get('USD')

            if ltc_price_usd is None:
                raise ValueError("Failed to retrieve the Litecoin price.")

            meow = self.amount_usd - 0.01
            ltc_amount = meow / float(ltc_price_usd)
            with open('private.json') as f:
                private_data = json.load(f)

            wallet_info = private_data.get(self.code)
            print(wallet_info)
            if wallet_info is None:
                raise ValueError("Invalid deal code.")

            address = wallet_info["address"]
            private_key = wallet_info["private_key"]

            total_balance = blockcypher.get_total_balance(address=address, coin_symbol="ltc", api_key=API_TOKEN)
            if total_balance < ltc_amount:
                return await interaction.send("You do not have enough balance to send LTC.")

       
            

        
            transaction = blockcypher.simple_spend(from_privkey=private_key, to_address=ltc_address, to_satoshis=int(ltc_amount * 1e8), coin_symbol="ltc", api_key=API_TOKEN)
            transaction_url = f"https://live.blockcypher.com/ltc/tx/{transaction}"


  
            embed = discord.Embed(
                title="Litecoin Released!",
                description="A signed transaction has been created.",
               color=0x5CDBF0,
               timestamp=discord.utils.utcnow()
            )
            embed.add_field(name="From", value=address, inline=False)
            embed.add_field(name="To", value=ltc_address, inline=False)
            embed.add_field(name="Amount (USD)", value=f"{meow:.2f} USD", inline=True)
            embed.add_field(name="Amount (LTC)", value=f"{ltc_amount:.8f} LTC", inline=True)
            embed.add_field(name="Blockchain", value=f"[{transaction}]({transaction_url})", inline=False)

            await interaction.channel.send(embed=embed)
            if os.path.exists(file_path):
                with open(file_path, 'r') as file:
                    data = json.load(file)

                if code in data:
                    data[code]["status"] = "Released"

                with open(file_path, 'w') as file:
                    json.dump(data, file, indent=4)


        except Exception as e:
            await interaction.channel.send(f"An error occurred: {e}")



@bot.command()
async def test_deal_action(ctx, receiver: discord.Member, code: str, amount: float):
    sender = ctx.author

    view = DealActionView(sender, receiver, code, amount)
    deal_action_embed = discord.Embed(
        title="Deal Action",
        description="Click the button to release the deal.",
        color=discord.Color.green()
    )

    await ctx.send(embed=deal_action_embed, view=view)

@bot.command()
@commands.has_role(1299725673551888447)
async def refund(ctx, code:str, addy:str):
        try:
            
            file_path = 'ltc.json'
            if not os.path.exists(file_path):
                return await ctx.send("The deals file was not found.")

            with open(file_path, 'r') as file:
                data = json.load(file)

            deal_info = data.get(code)
            if deal_info is None:
                return await ctx.send("Invalid deal code.")
            

            ltc_amount = deal_info.get("deal_amt")
            deal_sender_id = deal_info.get("sender_id") 
            if ltc_amount is None or deal_sender_id is None:
                return await ctx.send("The deal code is missing required information.")

           
            wallet_info = deal_info.get("wallet_info")
            address = wallet_info["address"]
            private_key = wallet_info["private_key"]

            total_balance = get_total_balance(address=address, coin_symbol="ltc", api_key=API_TOKEN)
            if total_balance < ltc_amount:
                return await ctx.send("Not enough balance for a refund.")


        
            transaction = simple_spend(
                from_privkey=private_key,
                to_addy=addy,
                to_satoshis=int(ltc_amount * 1e8),  
                coin_symbol="ltc",
                api_key=API_TOKEN
            )
            transaction_url = f"https://live.blockcypher.com/ltc/tx/{transaction['tx_hash']}"

   
            embed = discord.Embed(
                title="Refund Issued",
                description="A refund transaction has been created.",
                color=0xb28fe8,
                timestamp=discord.utils.utcnow()
            )
            embed.add_field(name="To", value=addy, inline=False)
            embed.add_field(name="Amount (LTC)", value=f"{ltc_amount:.8f} LTC", inline=True)
            embed.add_field(name="Blockchain", value=f"[Transaction Link]({transaction_url})", inline=False)
            await ctx.send(embed=embed)

    
            data[code]["status"] = "Refunded"
            with open(file_path, 'w') as file:
                json.dump(data, file, indent=4)

        except Exception as e:
            await ctx.send(f"An error occurred: {e}")


@bot.command()
async def close(ctx):
    transcript_channel_id = # Add a transcript channel ID here
    ticket_channel = ctx.channel
    transcript_channel = ctx.guild.get_channel(transcript_channel_id)
    transcript = await chat_exporter.export(ticket_channel)
    transcript_file = discord.File(io.BytesIO(transcript.encode()), filename=f"{ticket_channel.name}.html")

    await transcript_channel.send(file=transcript_file)
    if transcript_file:
        await ctx.channel.delete()


bot.run('TOKEN', reconnect=True)

# bot.run('TOKEN', reconnect=True)   # ADD YOUR TOKEN, OR LINK TO A .ENV



