
import disnake
from disnake.ext import commands
import json
import chat_exporter
import io



intents = disnake.Intents.all()
bot = commands.Bot(command_prefix='>', intents=intents)


def load_user_tickets():
    try:
        with open("user_tickets.json", "r") as file:
            content = file.read()
            if not content.strip():
                return {}
            return json.loads(content)
    except FileNotFoundError:
        print("user_tickets.json file not found.")
        return {}
    except json.JSONDecodeError as e:
        print(f"Error decoding JSON from user_tickets.json: {str(e)}")
        return {}

def save_user_tickets(user_tickets):
    try:
        with open('user_tickets.json', 'w') as file:
            json.dump(user_tickets, file, indent=4)
    except Exception as e:
        print(f"Error saving user tickets: {e}")

user_tickets = load_user_tickets()


if user_tickets:
    for user_id, tickets in user_tickets.items():
        for channel_id, ticket_type in tickets:
            print("User ID:", user_id)
            print("Channel ID:", channel_id)
            print("Ticket Type:", ticket_type)
else:
    print("No user tickets found.")



@bot.event
async def on_ready():
    print(f'Logged in as {bot.user}')
    await bot.change_presence(activity=disnake.Activity(type=disnake.ActivityType.watching, name=f"{str(len(bot.guilds))} Guilds!"))



# setup
@bot.slash_command(description="Setup ticket bot")
async def setup(inter:disnake.ApplicationCommandInteraction, buy_category: disnake.CategoryChannel = None, support_category: disnake.CategoryChannel = None, report_category: disnake.CategoryChannel = None, staff_role:disnake.Role = None, transcript_channel: disnake.TextChannel = None):
    guild_id = inter.guild.id
    filename = f"config_{guild_id}.json"
    config_data = {}

    try:
         with open(filename, "r") as config_file:
              config_data = json.load(config_file)
    except FileNotFoundError:
        config_data = {}

    if buy_category:
        config_data["buy_category_id"] = str(buy_category.id)
    if support_category:
        config_data["support_category_id"] = str(support_category.id)
    if report_category:
        config_data["report_category_id"] = str(report_category.id)
    if staff_role:
        config_data["staff_role_id"] = str(staff_role.id)
    if transcript_channel:
        config_data["transcript_channel_id"] = str(transcript_channel.id)

    try:
        with open(filename, "w") as config_file:
            json.dump(config_data, config_file, indent=4)
        await inter.send("Configuration updated successfully!", ephemeral=True, delete_after=5)
    except Exception as e:
        await inter.send(f"Error updating configuration: {e}", ephemeral=True, delete_after=5)
        return

    await inter.send("Setup is now completed. The prefix for this bot is `!` To continue use `!help`", ephemeral=True, delete_after=5)




class SelectTicket(disnake.ui.Select):
    def __init__(self):
        options = [
            disnake.SelectOption(label="Buy", value="buy"),
            disnake.SelectOption(label="Support", value="support"),
            disnake.SelectOption(label="Report", value="report")]
        super().__init__(placeholder="Select one to open a ticket!", options=options, custom_id="tickets", min_values=1, max_values=1)
    
    
    async def callback(self, inter: disnake.MessageInteraction):
        ticket_type = self.values[0]
        await ticketcallback(inter, ticket_type)






# transcript_callback

async def transcript_callback(inter:disnake.ApplicationCommandInteraction):
    guild_id = inter.guild.id
    filename = f"config_{guild_id}.json"
    ticket_channel = inter.channel
    if not inter.user.guild_permissions.administrator:
        await inter.response.send_message("You do not have the required permissions to use this button.", ephemeral=True, delete_after=5)
        return
    else:
        try:
            with open(filename, "r") as config_file:
                config_data = json.load(config_file)
            transcript_channel_id = int(config_data.get("transcript_channel_id"))
            transcript_channel = inter.guild.get_channel(transcript_channel_id)
        except Exception as e:
            print(f"Error loading configuration: {e}", ephemeral=True, delete_after=5)
            await inter.response.send_message("Failed to load bot configuration. Please contact an administrator.", ephemeral=True, delete_after=5)
            return
        
        if transcript_channel:
            transcript = await chat_exporter.export(ticket_channel)
            transcript_file = disnake.File(io.BytesIO(transcript.encode()), filename=f"{ticket_channel.name}.html")

            await transcript_channel.send(file=transcript_file)
            embed = disnake.Embed(
                    title=" ",
                    description=f"Transcript for {ticket_channel.name} Saved!",
                    color = disnake.Colour.magenta()
                )

            await inter.send(embed=embed)

# ticket_callback

async def ticket_callback(inter:disnake.ApplicationCommandInteraction):
    user_tickets = load_user_tickets()
    channel_id = str(inter.channel.id)

    guild = inter.guild
    member = guild.get_member(inter.user.id)

    if member:
        tickets_deleted = False
        for user_id, tickets in user_tickets.items():
            for ticket in tickets[:]:
                if ticket[0] == channel_id:
                    tickets.remove(ticket)
                    tickets_deleted = True
       
        if tickets_deleted:
            save_user_tickets(user_tickets)
            try:
                await inter.channel.delete()
                await inter.response.send_message("Ticket channel deleted successfully.", ephemeral=True)
            except disnake.HTTPException as e:
                print(f"Failed to delete channel: {e}")
                await inter.response.send_message("Failed to delete the ticket channel.", ephemeral=True)
        else:
            await inter.response.send_message("No tickets associated with this channel.", ephemeral=True)
    else:
        await inter.response.send_message("Failed to identify the member.", ephemeral=True)


# ticketcallback

async def ticketcallback(inter:disnake.ApplicationCommandInteraction, ticket_type):
    user_tickets = load_user_tickets()
    user_id = str(inter.user.id)
    guild_id = inter.guild.id
    filename = f"config_{guild_id}.json"
    try:
        with open(filename, "r") as config_file:
            config_data = json.load(config_file)
        buy_category_id = int(config_data.get("buy_category_id"))
        support_category_id = int(config_data.get("support_category_id"))
        report_category_id = int(config_data.get("report_category_id"))
        staff_role_id = int(config_data.get("staff_role_id"))

    except Exception as e:
        print(f"Error loading configuration: {e}")
        await inter.response.send_message("Failed to load bot configuration. Please contact an administrator.", ephemeral=True)
        return

    if user_id in user_tickets and any(ticket_type == t_type for _, t_type in user_tickets[user_id]):
        await inter.response.send_message("You have already opened a ticket of this type!", ephemeral=True)
        return

    guild = inter.guild
    channel_id = None

    category_ids = {
        "buy": buy_category_id,
        "support": support_category_id,
        "report": report_category_id
    }

    category_id = category_ids.get(ticket_type)
    if not category_id:
        await inter.response.send_message("Invalid Ticket Type!", ephemeral=True)
        return

    try:
        if ticket_type == "buy":
            channel_name = f"{inter.user.name}-buy-ticket"
        elif ticket_type == "report":
            channel_name = f"{inter.user.name}-report-ticket"
        elif ticket_type == "support":
            channel_name = f"{inter.user.name}-support-ticket"
        else:
            await inter.response.send_message("Invalid Ticket Type!", ephemeral=True)
            return

        category = guild.get_channel(category_id)
        channel = await guild.create_text_channel(channel_name, category=category)
        channel_id = str(channel.id)

        if user_id not in user_tickets:
            user_tickets[user_id] = [(channel_id, ticket_type)]
        else:
            user_tickets[user_id].append((channel_id, ticket_type))

        save_user_tickets(user_tickets)

        staff_role = guild.get_role(staff_role_id)
        overwrites = {
            guild.default_role: disnake.PermissionOverwrite(view_channel=False),
            inter.user: disnake.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True),
        }

        if staff_role:
            overwrites[staff_role] = disnake.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True)
        else:
            print(f"Staff role with ID {staff_role_id} not found.")

        await channel.edit(overwrites=overwrites)

        await inter.response.send_message(f"Created Ticket - <#{channel.id}>", ephemeral=True)

        icon_url = inter.guild.icon.url if inter.guild.icon else None

        embed = disnake.Embed(colour=disnake.Colour.magenta())

        if ticket_type == "buy":
            embed.title = "**__Buy Ticket__**"
            embed.description = f"Welcome {inter.user.mention}! Please fill in this form while you wait!"
            embed.add_field(name="` Product: (What do you want to buy?) `", value=" ", inline=False)
            embed.add_field(name="` Quantity: (How Many?) `", value=" ", inline=False)
            embed.add_field(name="` Payment Method: (LTC | ETH | PP) `", value=" ", inline=False)

        elif ticket_type == "report":
            embed.title = "**__Report Ticket__**"
            embed.description = f"Welcome {inter.user.mention}! Please fill in this form below! Please include full screenshots of any proof!"
            embed.add_field(name="` Accused User ID: `", value=" ", inline=False)
            embed.add_field(name="` Victim User ID: `", value=" ", inline=False)
            embed.add_field(name="` Accusation: `", value=" ", inline=False)
            embed.add_field(name="` Proof: `", value=" ", inline=False)

        elif ticket_type == "support":
            embed.title = "**__Support Ticket__**"
            embed.description = f"Welcome {inter.user.mention}! Please describe your issue below!"
            embed.add_field(name="> - Be patient we are very busy!", value=" ", inline=False)
            embed.add_field(name="> - Only ping us once!", value=" ", inline=False)

        if icon_url:
            embed.set_thumbnail(url=icon_url)
    
        if guild.banner:
            banner_url = f'https://cdn.disnakeapp.com/banners/{inter.guild.id}/{inter.guild.banner}.png?size=1024'
            embed.set_image(url=banner_url)
        else:
            embed.set_image(url="")  # Optional: Set a default image if the guild has no banner

        embed.set_footer(text=".gg/riches")

        button_transcript = disnake.ui.Button(style=disnake.ButtonStyle.green, label="Transcript")
        button_transcript.callback = transcript_callback

        button_close = disnake.ui.Button(style=disnake.ButtonStyle.red, label="Close Ticket")
        button_close.callback = ticket_callback
        
        view = disnake.ui.View(timeout=None)
        view.add_item(button_close)
        view.add_item(button_transcript)

        await channel.send(embed=embed, view=view)
        print(f"User ID: {user_id}")
        print(f"Ticket Type: {ticket_type}")
        print(f"Channel ID: {channel_id}")

    except disnake.HTTPException as e:
        print(f"Error creating channel: {e}")
        await inter.response.send_message("Failed to create a ticket channel. Please try again later.", ephemeral=True)


@bot.command()
@commands.has_permissions(administrator=True)
async def sendticket(inter:disnake.ApplicationCommandInteraction):
    
    guild = inter.guild


    embed = disnake.Embed(title="**__Tickets__**", description="Please be patient after opening a ticket!", colour=disnake.Colour.magenta())
    embed.add_field(name="> - Please choose what type of ticket from the dropdown below!", value=" ", inline=False)
    embed.add_field(name="> - Please only use buy tickets if you are money ready!", value=" ", inline=False)
    embed.set_thumbnail(url=inter.guild.icon)

    if guild.banner:
        banner_url = f'https://cdn.disnakeapp.com/banners/{guild.id}/{guild.banner}.png?size=1024'
        embed.set_image(url=banner_url)
    else:
        embed.set_image(url="")  # Optional: Set a default image if the guild has no banner

    embed.set_footer(text=".gg/riches")

    view = disnake.ui.View(timeout=None)
    view.add_item(SelectTicket())

    await inter.send(embed=embed, view=view)





@bot.slash_command(description="Add a member to the ticket.")
@commands.has_permissions(administrator=True)
async def addmember(inter, user: disnake.User):
    guild_id = inter.guild.id
    channel = inter.channel
    try:
        if isinstance(channel, disnake.TextChannel):
                await channel.set_permissions(user, read_messages=True, send_messages=True)
                embed = disnake.Embed(
                    title=" ",
                    description=f"Added {user.mention} to the ticket",
                    color = disnake.Colour.magenta()
                )

                await inter.send(embed=embed)
        else:
                await inter.send("This command must be used in a ticket channel.", ephemeral=True, delete_after=5)
    except Exception as e:
        print(f"Error loading configuration: {e}", ephemeral=True, delete_after=5)
        await inter.send("Failed to load bot configuration. Please contact an administrator.", ephemeral=True, delete_after=5)

bot.run('') # add token
